package topic1;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Job {
//	"OCCU_DESC","WK_TYPE","CJOB_TYPE","CJOB_NAME1","CJOB_NO",
//	"CJOB_NAME2","AVAILREQNUM","STOP_DATE","JOB_DETAIL","CITYNAME","EXPERIENCE","WKTIME","SALARYCD",
//	"SALARY_L","SALARY_U","EDGRDESC","URL_QUERY","COMPNAME","TRANDATE"
	
	private int id;
	private String OCCU_DESC;
	private String WK_TYPE;
	private String CJOB_TYPE;
	private String CJOB_NAME1;
	private String CJOB_NO;
	private String CJOB_NAME2;
	private String AVAILREQNUM;
	private String STOP_DATE;
	private String JOB_DETAIL;
	private String CITYNAME;
	private String EXPERIENCE;
	private String WKTIME;
	private String SALARYCD;
	private String SALARY_L;
	private String SALARY_U;
	private String EDGRDESC;
	private String URL_QUERY;
	private String COMPNAME;
	private String TRANDATE;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOCCU_DESC() {
		return OCCU_DESC;
	}
	public void setOCCU_DESC(String oCCU_DESC) {
		OCCU_DESC = oCCU_DESC;
	}
	public String getWK_TYPE() {
		return WK_TYPE;
	}
	public void setWK_TYPE(String wK_TYPE) {
		WK_TYPE = wK_TYPE;
	}
	public String getCJOB_TYPE() {
		return CJOB_TYPE;
	}
	public void setCJOB_TYPE(String cJOB_TYPE) {
		CJOB_TYPE = cJOB_TYPE;
	}
	public String getCJOB_NAME1() {
		return CJOB_NAME1;
	}
	public void setCJOB_NAME1(String cJOB_NAME1) {
		CJOB_NAME1 = cJOB_NAME1;
	}
	public String getCJOB_NO() {
		return CJOB_NO;
	}
	public void setCJOB_NO(String cJOB_NO) {
		CJOB_NO = cJOB_NO;
	}
	public String getCJOB_NAME2() {
		return CJOB_NAME2;
	}
	public void setCJOB_NAME2(String cJOB_NAME2) {
		CJOB_NAME2 = cJOB_NAME2;
	}
	public String getAVAILREQNUM() {
		return AVAILREQNUM;
	}
	public void setAVAILREQNUM(String aVAILREQNUM) {
		AVAILREQNUM = aVAILREQNUM;
	}
	public String getSTOP_DATE() {
		return STOP_DATE;
	}
	public void setSTOP_DATE(String sTOP_DATE) {
		STOP_DATE = sTOP_DATE;
	}
	public String getJOB_DETAIL() {
		return JOB_DETAIL;
	}
	public void setJOB_DETAIL(String jOB_DETAIL) {
		JOB_DETAIL = jOB_DETAIL;
	}
	public String getCITYNAME() {
		return CITYNAME;
	}
	public void setCITYNAME(String cITYNAME) {
		CITYNAME = cITYNAME;
	}
	public String getEXPERIENCE() {
		return EXPERIENCE;
	}
	public void setEXPERIENCE(String eXPERIENCE) {
		EXPERIENCE = eXPERIENCE;
	}
	public String getWKTIME() {
		return WKTIME;
	}
	public void setWKTIME(String wKTIME) {
		WKTIME = wKTIME;
	}
	public String getSALARYCD() {
		return SALARYCD;
	}
	public void setSALARYCD(String sALARYCD) {
		SALARYCD = sALARYCD;
	}
	public String getSALARY_L() {
		return SALARY_L;
	}
	public void setSALARY_L(String sALARY_L) {
		SALARY_L = sALARY_L;
	}
	public String getSALARY_U() {
		return SALARY_U;
	}
	public void setSALARY_U(String sALARY_U) {
		SALARY_U = sALARY_U;
	}
	public String getEDGRDESC() {
		return EDGRDESC;
	}
	public void setEDGRDESC(String eDGRDESC) {
		EDGRDESC = eDGRDESC;
	}
	public String getURL_QUERY() {
		return URL_QUERY;
	}
	public void setURL_QUERY(String uRL_QUERY) {
		URL_QUERY = uRL_QUERY;
	}
	public String getCOMPNAME() {
		return COMPNAME;
	}
	public void setCOMPNAME(String cOMPNAME) {
		COMPNAME = cOMPNAME;
	}
	public String getTRANDATE() {
		return TRANDATE;
	}
	public void setTRANDATE(String tRANDATE) {
	}
	@Override
	public String toString() {
		return id+", "+OCCU_DESC + ", " + WK_TYPE + ", " + CJOB_TYPE + ", " + CJOB_NAME1 + ", " + CJOB_NO + ", " + CJOB_NAME2
				+ ", " + AVAILREQNUM + ", " + STOP_DATE + ", " + JOB_DETAIL + ", " + CITYNAME + ", " + EXPERIENCE + ", "
				+ WKTIME + ", " + SALARYCD + ", " + SALARY_L + ", " + SALARY_U + ", " + EDGRDESC + ", " + URL_QUERY
				+ ", " + COMPNAME + ", " + TRANDATE + "]";
	}
	
	public String Col() {
		return "ID"+", "+"OCCU_DESC" + ", " + "WK_TYPE" + ", " + "CJOB_TYPE" + ", " + "CJOB_NAME1" + ", " + "CJOB_NO" + ", " + "CJOB_NAME2"
				+ ", " + "AVAILREQNUM" + ", " + "STOP_DATE" + ", " + "JOB_DETAIL" + ", " + "CITYNAME" + ", " + "EXPERIENCE" + ", "
				+ "WKTIME" + ", " + "SALARYCD" + ", " + "SALARY_L" + ", " + "SALARY_U "+ ", " + "EDGRDESC" + ", " + "URL_QUERY"
				+ ", " + "COMPNAME" + ", " + "TRANDATE" + "]";
		
	}
	
	public static Job rsToJob( ResultSet rs ) throws SQLException {
		Job job = new Job();
		
		job.setId(rs.getInt(1));
		job.setOCCU_DESC( rs.getString(2));
		job.setWK_TYPE( rs.getString(3));
		job.setCJOB_TYPE( rs.getString(4));
		job.setCJOB_NAME1( rs.getString(5));
		job.setCJOB_NO( rs.getString(6));
		job.setCJOB_NAME2( rs.getString(7));
		job.setAVAILREQNUM( rs.getString(8));
		job.setSTOP_DATE( rs.getString(9));
		job.setJOB_DETAIL( rs.getString(10));
		job.setCITYNAME( rs.getString(11));
		job.setEXPERIENCE( rs.getString(12));
		job.setWKTIME( rs.getString(13));
		job.setSALARYCD( rs.getString(14));
		job.setSALARY_L( rs.getString(15));
		job.setSALARY_U( rs.getString(16));
		job.setEDGRDESC( rs.getString(17));
		job.setURL_QUERY( rs.getString(18));
		job.setCOMPNAME( rs.getString(19));
		job.setTRANDATE( rs.getString(20));
		return job;
	}
	
	
	
	
}
