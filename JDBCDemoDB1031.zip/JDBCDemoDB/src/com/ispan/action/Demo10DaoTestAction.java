package com.ispan.action;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.ispan.model.Member;
import com.ispan.model.MemberDao;
import com.ispan.util.ConnectionFactory;

public class Demo10DaoTestAction {

	public static void main(String[] args) {
		Connection conn = ConnectionFactory.createMSSQLConnection();
		
		MemberDao mDao = new MemberDao(conn);
		
		try {
			
//			Member m1 = new Member(1001,"Tom","Tainan","06-1233333");
//			mDao.addMember(m1);
//			
//			Member m2 = new Member(1002,"Amy","新竹", "091234566");
//			mDao.addMember(m2);
			
//			Member tempMember = mDao.findById(1002);
//			System.out.println(tempMember);
			
//			List<Member> result = mDao.getAllMember();
//			for(Member mb :result) {
//				System.out.println(mb);
//			}
			
//			mDao.updatePhoneById(1002, "88888888");
			
//			Member tempMember = mDao.findById(1002);
//			mDao.deleteMember(tempMember);
			
			List<Member> list = mDao.findByAddressLike("ta");
			
			if(list.size() > 0) {
				for(Member m :list) {
					System.out.println(m);
				}
			} else {
				System.out.println("沒有相符的資料");
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}