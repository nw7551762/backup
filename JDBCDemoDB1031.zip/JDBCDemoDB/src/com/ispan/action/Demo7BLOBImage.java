package com.ispan.action;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo7BLOBImage {
	private Connection conn;
	
	public static void main(String[] args) {

		Demo7BLOBImage demo7 = new Demo7BLOBImage();
		
		try {
			demo7.createConnection();
//			demo7.saveImageInDB();
//			demo7.retrieveImage2("google");
//			demo7.testMetaData();
			demo7.testResultSetMetadata();
		
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				demo7.closeConn();
			} catch (SQLException e) {
//				e.printStackTrace();
				System.out.println(e.getMessage());
				System.out.println(e.getErrorCode());
			}
		}
	}
	
	public void retrieveImage3( String name ) throws SQLException, IOException {
		String sql = "  ";
		PreparedStatement state = conn.prepareStatement(sql);
		state.setString(1, name);
		ResultSet rs = state.executeQuery();
		rs.next();
		
		Blob blob = rs.getBlob(1);
		
		File file = new File("C:\\JDBC\\ouput.png");
		FileOutputStream fio = new FileOutputStream(file);
		fio.write(  blob.getBytes( 1, (int)blob.length())  )  ;
		
		fio.close();
		rs.close();
		state.close();
		System.out.println("讀取成功");
	}

	public void retrieveImage2(String imageName) throws SQLException, IOException {
        String sql = "select img_file from myImage where img_name = ?";
		
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setString(1, imageName);
		
		ResultSet rs = preState.executeQuery();
		
		rs.next();
		Blob blob = rs.getBlob(1);
		
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("C:/JDBC/image/out-result2.jpg"));
		bos.write(blob.getBytes(1, (int)blob.length()));
//		bos.write( rs.getBytes(1) );
		
		bos.flush(); // 檔案小於 8kb 時，需強制寫出記憶體
		
		System.out.println("檔案輸出OK");
		
		bos.close();
		rs.close();
		preState.close();
		
	}
	
	public void testMetaData() throws SQLException {
		DatabaseMetaData metadata = conn.getMetaData();
		
		System.out.println("DatabaseProductName: " + metadata.getDatabaseProductName());
		System.out.println("DatabaseMajorVersion: " + metadata.getDatabaseMajorVersion());
		System.out.println("DriverName:" + metadata.getDriverName());
		System.out.println("DriverVersion:" + metadata.getDriverVersion());
		System.out.println("UserName:" + metadata.getUserName());
	}
	
	public void testResultSetMetadata() throws SQLException {
		String sql = "select * from product";
		Statement state = conn.createStatement();
		ResultSet rs = state.executeQuery(sql);
		
		ResultSetMetaData meta = rs.getMetaData();
		
		System.out.println("ColumnCount"+ meta.getColumnCount());
		System.out.println("ColumnName(1)"+ meta.getColumnName(1));
		System.out.println("ColumnName(2)"+ meta.getColumnName(2));
		System.out.println("ColumnTypeName(1)"+ meta.getColumnTypeName(1));
		System.out.println("ColumnTypeName(2)"+ meta.getColumnTypeName(2));
		System.out.println("ColumnDisplaySize(1)"+ meta.getColumnDisplaySize(1));
		System.out.println("ColumnDisplaySize(2)"+ meta.getColumnDisplaySize(2));
		
		rs.close();
		state.close();
	}
	
	public void retrieveImage(String imageName) throws SQLException, IOException {
		String sql = "select img_file from myImage where img_name = ?";
		
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setString(1, imageName);
		
		ResultSet rs = preState.executeQuery();
		
		rs.next();
		InputStream binaryStream = rs.getBinaryStream(1);
		Blob blob = rs.getBlob(1);
		
		FileOutputStream fos = new FileOutputStream("C:/JDBC/image/out-result.jpg");
		fos.write(blob.getBytes(1, (int)blob.length()));
//		fos.write(blob.getBytes(1, 5000));
		
		System.out.println("Out Put OK!!!");
		
		fos.close();
		rs.close();
		preState.close();
	}
	
	public void saveImageInDB() throws SQLException, IOException {
		File file = new File("C:\\JDBC\\google.png");
		FileInputStream fis = new FileInputStream(file);
		
		String sql = "insert into myImage values( ?, ? )";
		PreparedStatement prestate = conn.prepareStatement(sql);
		prestate.setString(1, "google");
		prestate.setBinaryStream(2, fis);
		
		prestate.execute();
		prestate.close();
		fis.close();
		System.out.println("image saved");
		
	}
	
	public void createConnection() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;TrustServerCertificate=true;"
				+ "user=sa;password=00000000";
		this.conn = DriverManager.getConnection(urlStr);
		boolean status = !conn.isClosed();
		
		if(status) {
			System.out.println("開啟連線");
		}
		
	}
	
	public void closeConn() throws SQLException {
		if( conn != null  ) { 
			conn.close();
			System.out.println("連線關閉");
		}
	}
	
	
}
