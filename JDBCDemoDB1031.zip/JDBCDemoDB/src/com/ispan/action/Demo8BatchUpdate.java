package com.ispan.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class Demo8BatchUpdate {
	private Connection conn;
	
	public void couponSending() throws SQLException {
		ArrayList<String> emails = new ArrayList<String>();
		emails.add("jerry@gmail");
		emails.add("Amy@gmail");
		emails.add("a-wun@gmail");
		
		String sql = "insert into coupon(userEmail, couponCode) values (?,?)";
		
		PreparedStatement preState = conn.prepareStatement(sql);
		
		for(String email : emails) {
			preState.setString(1, email);
			preState.setString(2, "uuuuuuuuuuuuuuuu");
			preState.addBatch();  // 隱含的 List
		}
		
		preState.executeBatch(); // 真正執行批次
		
		System.out.println("批次執行OK");
		
		preState.close();
	}

	public static void main(String[] args) {
		Demo8BatchUpdate demo8 = new Demo8BatchUpdate();
		
		try {
			demo8.createConnection();
			demo8.couponSending();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				demo8.closeConn();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
	public void createConnection() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;TrustServerCertificate=true;"
				+ "user=sa;password=00000000";
		this.conn = DriverManager.getConnection(urlStr);
		boolean status = !conn.isClosed();
		
		if(status) {
			System.out.println("開啟連線");
		}
		
	}
	
	public void closeConn() throws SQLException {
		if( conn != null  ) { 
			conn.close();
			System.out.println("連線關閉");
		}
	}
	
}
