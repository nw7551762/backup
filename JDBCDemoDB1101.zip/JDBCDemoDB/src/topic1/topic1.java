package topic1;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.zip.CheckedOutputStream;

import javax.imageio.stream.FileImageOutputStream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.w3c.dom.ls.LSOutput;

import com.ispan.util.ConnectionFactory;

//run in cmd
//java -cp ".;C:\JDBC/mssql-jdbc-11.2.0.jre8.jar" topic1.topic1 



public class topic1 {
	public static void main(String[] args) {

		File file = new File("C:\\java\\joblist.csv");
		File outputfile = new File("C:\\java\\joblistSearchData.csv");
		Connection conn = ConnectionFactory.createMSSQLConnection();
		Topic1Dao dao = new Topic1Dao(conn);    	
		
		try (	FileInputStream fis = new FileInputStream(file);
				InputStreamReader isr = new InputStreamReader(fis,"utf8");
				BufferedReader br = new BufferedReader(isr);
				
				FileOutputStream fos = new FileOutputStream( outputfile);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				){
				// input CSV
				Iterable<CSVRecord> records;
				records = CSVFormat.EXCEL.parse(isr);
				
						
				//寫入資料庫
//				CSVInsertIntoJoblist(records,dao);
						
				//增加欄位
//				Job job = new Job();
//				job.setOCCU_DESC("test");
//				dao.insertjob(job);
				
				//修改
//				dao.updateSalById( 2, "30", "50"  );
				
				//搜尋by id
//				Job job = dao.search(3);
				//模糊搜尋 by col index and condition 
				List<Job> jobs = dao.search(1, "餐飲");
				
				//刪除欄位
//				dao.delete(jobs);
				
				//搜尋data output成 csv檔
//				jobOutputCsv(jobs, bos);
				
						
		} catch (IOException | SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			
			
	}	
	
	//job output成 csv檔
	public static void jobOutputCsv( Job job, BufferedOutputStream bos ) throws IOException {
		bos.write(  job.Col().getBytes()  );
		bos.write(  "\n".getBytes()  );
		bos.write(job.toString().getBytes());
		bos.write(  "\n".getBytes()  );
	}
	public static void jobOutputCsv( List<Job> jobs, BufferedOutputStream bos ) throws IOException {
		bos.write(  jobs.get(0).Col().getBytes()  );
		bos.write(  "\n".getBytes()  );
		for( int i =0; i<jobs.size(); i++ ) {
			bos.write(jobs.get(i).toString().getBytes());
			bos.write(  "\n".getBytes()  );
		}
	}
	
	
	public static void CSVInsertIntoJoblist( Iterable<CSVRecord> records, Topic1Dao dao) throws SQLException {
		//record讀出加到list內
		List<Job> joblist = new LinkedList<>();
		for( CSVRecord record : records ) {
			joblist.add( CSVRecordToJob(record) );
		}
		//寫入資料庫
		dao.insertJobs(joblist);
		System.out.println("資料庫寫入成功");
	}
	public static Job CSVRecordToJob( CSVRecord row ) {
		Job job = new Job();
		job.setOCCU_DESC( row.get(0) );
		job.setWK_TYPE( row.get(1) );
		job.setCJOB_TYPE( row.get(2) );
		job.setCJOB_NAME1( row.get(3) );
		job.setCJOB_NO( row.get(4) );
		job.setCJOB_NAME2( row.get(5) );
		job.setAVAILREQNUM( row.get(6) );
		job.setSTOP_DATE( row.get(7) );
		job.setJOB_DETAIL( row.get(8) );
		job.setCITYNAME( row.get(9) );
		job.setEXPERIENCE( row.get(10) );
		job.setWKTIME( row.get(11) );
		job.setSALARYCD( row.get(12) );
		job.setSALARY_L( row.get(13) );
		job.setSALARY_U( row.get(14) );
		job.setEDGRDESC( row.get(15) );
		job.setURL_QUERY( row.get(16) );
		job.setCOMPNAME( row.get(17) );
		job.setTRANDATE( row.get(18) );
		
		return job;
	}
}
