package com.ispan.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo3CreateStatement {
	
	private Connection conn;
	
	public void createConnection() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;TrustServerCertificate=true;user=sa;password=00000000";
		this.conn = DriverManager.getConnection(urlStr);
		boolean status = !conn.isClosed();
		if(status) {
			System.out.println("開啟連線");
		}
		
	}
	
	public void closeConn() throws SQLException {
		if(conn!=null) {
			conn.close();
			System.out.println("連線關閉");
		}
	}
	
	public void queryDB1() throws SQLException {
		String sql = "select * from product";
		Statement state = conn.createStatement();
		ResultSet rs = state.executeQuery(sql);
		System.out.println("result: " + rs.next());
		rs.close();
		state.close();
	}
	
	public void queryDB2() throws SQLException {
		String sql = "select * from product";
		Statement state = conn.createStatement();
		ResultSet rs = state.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3)
			+ " " + rs.getDate(4)+ " " + rs.getString(5));
		} 
		
		rs.close();
		state.close();
	}

	public void updateData() throws SQLException {
		String sql = "update product set productprice  =70 where productname= 'mask'";
		Statement state = conn.createStatement();
		int row = state.executeUpdate(sql);
		System.out.println("修改 " + row +" 筆資料");
		state.close();
		
	}
	
	public void up100product() throws SQLException {
		String sql = "select * from product where productprice >=100";
		Statement state = conn.createStatement();
		ResultSet rs = state.executeQuery(sql);
		while(rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3)
			+ " " + rs.getDate(4)+ " " + rs.getString(5));
		} 
		rs.close();
		state.close();
	}
	
	
	public void insertData() throws SQLException {
		String sql = "insert into product values ( '1005', 'ps5', '19000', '2022-10-26', '缺貨') ";
		Statement state = conn.createStatement();
		int row = state.executeUpdate(sql);
		System.out.println("加入 "+row+" 筆資料");
		state.close();
	}
	
	public void deleteById( Integer id ) throws SQLException {
		String sql = "delete from product where productid in (" + id + ")";
		Statement state = conn.createStatement();
		int row = state.executeUpdate(sql);
		System.out.println("刪除 "+row+" 筆資料");
		state.close();
	}
	
	public static void main(String[] args) {
		Demo3CreateStatement demo3 =new Demo3CreateStatement();
		
		try {
			
			demo3.createConnection();
			demo3.queryDB1();
//			demo3.queryDB2();
//			demo3.updateData();
//			demo3.insertData();
//			demo3.up100product();
//			demo3.deleteById( 1005 );
			
		} catch (SQLException e) {  
			e.printStackTrace();
		} finally {
			try {
				demo3.closeConn();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

	}

}