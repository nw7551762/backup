package com.ispan.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Demo4PreparedStatement {
	
    private Connection conn;
	
	public void createConnection() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;TrustServerCertificate=true;"
				+ "user=sa;password=00000000";
		this.conn = DriverManager.getConnection(urlStr);
		boolean status = !conn.isClosed();
		
		if(status) {
			System.out.println("開啟連線");
		}
		
	}
	
	public void closeConn() throws SQLException {
		if(conn!=null) {
			conn.close();
			System.out.println("連線關閉");
		}
	}
	
	public void createTable() throws SQLException {
		String sql = "create table profiles(id int primary key identity(1,1),name varchar(50) not null,"
				+ "address varchar(50) not null, phone varchar(20))";
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.execute();
		preState.close();
		System.out.println("create table success!!");
	}
	
	public void insertData(String name, String address, String phone) throws SQLException {
		String sql = "insert into profiles(name, address, phone) values (?,?,?)";
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setString(1, name);
		preState.setString(2, address);
		preState.setString(3, phone);
		
		int row = preState.executeUpdate();
		System.out.println("新增了 " + row + " 筆資料");
		preState.close();
	}

	public void updatePhoneByName(String name, String NewPhone) throws SQLException {

		String sql = "update profiles set phone = ? where name = ?";
		PreparedStatement prestate = conn.prepareStatement(sql);
		
		prestate.setString(1, NewPhone);
		prestate.setString(2, name);
		int row = prestate.executeUpdate();
		System.out.println("更改了 " + row + " 筆資料");
		prestate.close();
	}
	
	public void queryByAddress(String address) throws SQLException {
		String sql = "select * from profiles where address = ?";
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setString(1, address);
		ResultSet rs = preState.executeQuery();
		
		while(rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2)+ " " + rs.getString(3));
		}
		
		rs.close();
		preState.close();
		
	}
	
	public static void main(String[] args) {
		Demo4PreparedStatement demo4 = new Demo4PreparedStatement();
		
		try {
			demo4.createConnection();
//			demo4.createTable();
//			demo4.insertData("阿彭", "中壢", "666");
//			demo4.updatePhoneByName( "克拉克", "111"  );
			demo4.queryByAddress("中壢");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				demo4.closeConn();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}