package com.ispan.action;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.ispan.util.ConnectionFactory;

public class Demo9Transaction {
	
	private Connection conn;
	
	public Demo9Transaction(Connection conn) {
		this.conn = conn;
	}
	
	public void controllTransaction() {
		int[] i= {0,1,2,3,4,5,6};
		String sql1 = "update accounts set balance = balance + 600 where id = "+i;
		String sql2 = "update accounts set balance = balance - 600 where id = 2;";
		
		try {
			conn.setAutoCommit(false);
			
			Statement state = conn.createStatement();
			state.executeUpdate(sql1);
			state.executeUpdate(sql2);
			
			conn.commit();
			System.out.println("commit ok!!");
			
			conn.setAutoCommit(true);
		} catch (SQLException e) {
			System.out.println("Something Wrong and Rollback!!");
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		
	}

	public static void main(String[] args) {
		
		Connection conn = ConnectionFactory.createMSSQLConnection();
		
		Demo9Transaction demo9 = new Demo9Transaction(conn);
		
		demo9.controllTransaction();
		
	}

}