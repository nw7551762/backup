package com.ispan.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Demo2TryWithResource {

	public static void main(String[] args) {

		String urlstr = "jdbc:sqlserver://localhost:1433;"
				+ "databasename=JDBCDemoDB;"
				+ "TrustServerCertificate=true;"
				+ "user=sa;"
				+ "password=00000000";
		try(	Connection conn = DriverManager.getConnection(urlstr)
				){
			boolean status =  !conn.isClosed();
			System.out.println("status: "+status);
			System.out.println("ok");
			
		} catch (SQLException e) {
			System.out.println("有問題");
			e.printStackTrace();
		}
		
		
		
		
	}

}
