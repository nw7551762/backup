package com.ispan.action;

import java.net.ConnectException;
import java.rmi.ConnectIOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Demo1TestConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			
			String urlstr = "jdbc:sqlserver://localhost:1433;"
					+ "databasename=JDBCDemoDB;"
					+ "TrustServerCertificate=true";
			Connection conn = DriverManager.getConnection(urlstr, "sa", "00000000");
			boolean status = !conn.isClosed();
			
			
			
			
			System.out.println("status: "+ status);		
			System.out.println("找到了");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
