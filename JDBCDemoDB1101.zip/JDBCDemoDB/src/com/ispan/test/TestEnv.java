package com.ispan.test;

public class TestEnv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
