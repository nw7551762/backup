package topic1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class JDBC {
	private Connection conn;
	private String[] joblistLabel = {"OCCU_DESC","WK_TYPE","CJOB_TYPE","CJOB_NAME1","CJOB_NO",
			"CJOB_NAME2","AVAILREQNUM","STOP_DATE","JOB_DETAIL","CITYNAME","EXPERIENCE","WKTIME","SALARYCD",
			"SALARY_L","SALARY_U","EDGRDESC","URL_QUERY","COMPNAME","TRANDATE","desciption","desciption1",""};
	
	public JDBC() throws SQLException {
		createConn();
	}
	
	
	
	
	public void createConn() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;TrustServerCertificate=true;"
				+ "user=sa;password=00000000";
		this.conn = DriverManager.getConnection(urlStr);
		
		if( !conn.isClosed() ) {
			System.out.println("連線開啟");
		}
		
	}

	public void closeConn() throws SQLException {
		if( conn!=null ) {
			conn.close();
			System.out.println("連線關閉");
		}
	}

	public void updateRow( CSVRecord record ) throws SQLException {
		String sql = "insert into joblist values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		for( int i=1; i<=19; i++ ) {
			ps.setString( i , record.get(i-1) );
		}
		
		ps.execute();
		ps.close();
		System.out.println("新增 1筆資料");
	}
}
