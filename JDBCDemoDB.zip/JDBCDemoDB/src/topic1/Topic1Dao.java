package topic1;

import java.io.Closeable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.ispan.util.ConnectionFactory;

public class Topic1Dao {
	private Connection conn;
	
	public Topic1Dao(Connection conn) {
		this.conn = conn;
	}

	public void insertjob( Job job ) throws SQLException {
		String sql = "insert into joblist values( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, job.getOCCU_DESC() );
		ps.setString(2,job.getWK_TYPE());
		ps.setString(3,job.getCJOB_TYPE());
		ps.setString(4,job.getCJOB_NAME1());
		ps.setString(5,job.getCJOB_NO());
		ps.setString(6,job.getCJOB_NAME2());
		ps.setString(7,job.getAVAILREQNUM());
		ps.setString(8,job.getSTOP_DATE());
		ps.setString(9,job.getJOB_DETAIL());
		ps.setString(10,job.getCITYNAME());
		ps.setString(11,job.getEXPERIENCE());
		ps.setString(12,job.getWKTIME());
		ps.setString(13,job.getSALARYCD());
		ps.setString(14,job.getSALARY_L());
		ps.setString(15,job.getSALARY_U());
		ps.setString(16,job.getEDGRDESC());
		ps.setString(17,job.getURL_QUERY());
		ps.setString(18,job.getCOMPNAME());
		ps.setString(19,job.getTRANDATE());
		
		ps.executeUpdate();
		
		ps.close();
		
		
	}

	public void insertJobs( List<Job> list ) throws SQLException{
		for( Job job : list ) {
			String sql = "insert into joblist values( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, job.getOCCU_DESC() );
			ps.setString(2,job.getWK_TYPE());
			ps.setString(3,job.getCJOB_TYPE());
			ps.setString(4,job.getCJOB_NAME1());
			ps.setString(5,job.getCJOB_NO());
			ps.setString(6,job.getCJOB_NAME2());
			ps.setString(7,job.getAVAILREQNUM());
			ps.setString(8,job.getSTOP_DATE());
			ps.setString(9,job.getJOB_DETAIL());
			ps.setString(10,job.getCITYNAME());
			ps.setString(11,job.getEXPERIENCE());
			ps.setString(12,job.getWKTIME());
			ps.setString(13,job.getSALARYCD());
			ps.setString(14,job.getSALARY_L());
			ps.setString(15,job.getSALARY_U());
			ps.setString(16,job.getEDGRDESC());
			ps.setString(17,job.getURL_QUERY());
			ps.setString(18,job.getCOMPNAME());
			ps.setString(19,job.getTRANDATE());
			
			ps.executeUpdate();
			
			ps.close();
		}
	}
	
	public void deleteById( int id  ) throws SQLException {
		String sql = "delete from joblist where id  = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeLargeUpdate();
		
		ps.close();
	}
	public void deleteById( int[] arr ) throws SQLException{
		for( int i=0; i<arr.length;i++ ) {
			String sql = "delete from joblist where id  = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, arr[i]);
			ps.executeLargeUpdate();
			
			ps.close();
		}
	}
	
	public void updateSalById( int id, String salL, String salU ) throws SQLException {
		String sql = "update joblist set SALARY_L = ? , SALARY_U = ? where id = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, salL);
		ps.setString(2, salU);
		ps.setInt(3, id);
		
		ps.executeUpdate();
		ps.close();
	}
		
	public void search(int id) throws SQLException{
		String sql = "select * from joblist where id = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		
		ResultSet rs = ps.executeQuery();
		rs.next();
		Job job = Job.rsToJob(rs);
		System.out.println(job);
		
		
		ps.close();
	}
		
	}
	
	
	
	
	




