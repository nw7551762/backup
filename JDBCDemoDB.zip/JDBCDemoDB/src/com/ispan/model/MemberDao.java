package com.ispan.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MemberDao {
	
	private Connection conn;
	
	public MemberDao(Connection conn) {
		this.conn = conn;
	}
	
	// 新增資料
	public void addMember(Member m) throws SQLException {
		String sql = "insert into member values (?,?,?,?)";
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setInt(1, m.getId());
		preState.setString(2, m.getName());
		preState.setString(3, m.getAddress());
		preState.setString(4, m.getPhone());
		int row = preState.executeUpdate();
		System.out.println("新增了 " + row + " 筆");
		preState.close();
	}
	
	// 拿全部資料，回傳 List<Member>
	public List<Member> getAllMember() throws SQLException{
		String sql = "select * from member";
		
		// preparedstatement
		PreparedStatement preState = conn.prepareStatement(sql);
		
		// 執行拿到 ResultSet
		ResultSet rs = preState.executeQuery();
		
		// 準備空的 List<Member>
		List<Member> list = new ArrayList<Member>();
		
		// 一筆一筆讀 ResultSet, 
		// new Member add 到 list
		while(rs.next()) {
			Member m = new Member();
			m.setId(rs.getInt("id"));
			m.setName(rs.getString("member_name"));
			m.setAddress(rs.getString("member_address"));
			m.setPhone(rs.getString("member_phone"));
			list.add(m);
		}
		
		rs.close();
		preState.close();
		
		// 回傳 List
		return list;
	}
	
	// 透過 id 拿資料
	public Member findById(Integer id) throws SQLException {
		String sql = "select * from member where id = ?";
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setInt(1, id);
		
		ResultSet rs = preState.executeQuery();
		rs.next();
		
		Member m = new Member();
		
		m.setId(rs.getInt("id"));
		m.setName(rs.getString("member_name"));
		m.setAddress(rs.getString("member_address"));
		m.setPhone(rs.getString("member_phone"));
		
		rs.close();
		preState.close();
		
		return m;
	}
	
	// 修改資料
	// 給 id 想要改電話
	public void updatePhoneById(Integer id, String newPhone) throws SQLException {
		String sql = "update member set member_phone = ? where id = ?";
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setInt(2, id);
		preState.setString(1, newPhone);
		
		preState.executeUpdate();
		
		System.out.println("修改完成!!");
		
		preState.close();
	}
	
	// 刪除資料用 id 找
	public void deleteMember(Integer id) throws SQLException {
		String sql = "delete from member where id = ?";
		PreparedStatement preState = conn.prepareStatement(sql);
		preState.setInt(1, id);
		preState.executeUpdate();
		System.out.println("刪除 OK");
		preState.close();
	}
	
	// 用物件刪除
    public void deleteMember(Member m) throws SQLException {
    	String sql = "delete from member where id = ?";
    	PreparedStatement preState = conn.prepareStatement(sql);
		preState.setInt(1, m.getId());
		preState.executeUpdate();
		System.out.println("刪除 OK");
		preState.close();
	}
	
	// 模糊搜尋寫法 where member_address like '%ta%'
    public List<Member> findByAddressLike(String address) throws SQLException {
    	String sql = "select * from member where member_address like ?";
    	PreparedStatement preState = conn.prepareStatement(sql);
    	preState.setString(1, "%" + address + "%");
    	ResultSet rs = preState.executeQuery();
    	
    	List<Member> list = new LinkedList<Member>();
    	
    	while(rs.next()) {
    		Member m = new Member();
			m.setId(rs.getInt("id"));
			m.setName(rs.getString("member_name"));
			m.setAddress(rs.getString("member_address"));
			m.setPhone(rs.getString("member_phone"));
			list.add(m);
    	}
    	
    	rs.close();
    	preState.close();
    	
    	return list;
    	
    }
	
	
	//... 某種條件找資料
	
	//...

}