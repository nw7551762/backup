package com.ispan.action;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Demo6StoreProcedure {
	private Connection conn;
	
	public static void main(String[] args) {
		
		
		
	}
	
	public void callProcedure(int productId) throws SQLException {
		CallableStatement callState = conn.prepareCall("{call productProc(?,?)}");
		callState.setInt(1, productId);
		callState.registerOutParameter(2, java.sql.Types.VARCHAR);
		
		callState.execute();
		
		String productName = callState.getString(2);
		
		System.out.println("Output productName: " + productName);
		
		callState.close();
	}

	
	public void createConnection() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;TrustServerCertificate=true;"
				+ "user=sa;password=00000000";
		this.conn = DriverManager.getConnection(urlStr);
		boolean status = !conn.isClosed();
		
		if(status) {
			System.out.println("開啟連線");
		}
		
	}
	
	public void closeConn() throws SQLException {
		if(conn!=null) {
			conn.close();
			System.out.println("連線關閉");
		}
	}
	
}
