package com.ispan.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo5SQLInjection {
	private Connection conn;
	
	public static void main(String[] args) {
		Demo5SQLInjection conn = new Demo5SQLInjection();
		
		try {
			conn.createConnection();
			
			boolean isLogin1 = conn.checkLogin1( "' or 1=1 --", "asdasd" );
			boolean isLogin2 = conn.checkLogin2( "' or 1=1 --", "asdasd" );
			if( isLogin2 ) {
				System.out.println("登入成功");
			}else{
				System.out.println("登入失敗");
			}
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				conn.closeConn();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public boolean checkLogin1( String username, String pwd ) throws SQLException {
		String sql = "select * from users where username = '" + username +
					"' and pwd = '" + pwd + "'" ;
		Statement state =  conn.createStatement();
		ResultSet rs = state.executeQuery(sql);
		boolean checkOK = rs.next();
		rs.close();
		state.close();
		return checkOK;
	}
	
	public boolean checkLogin2( String username, String pwd ) throws SQLException {
		String sql = "select * from users where name = ? and pwd = ? ";
		PreparedStatement prestate = conn.prepareStatement(sql);
		prestate.setString(1, username);
		prestate.setString(2, pwd);
		ResultSet rs = prestate.executeQuery(sql);
		boolean checkOK = rs.next();
		rs.close();
		prestate.close();
		return checkOK;
	}

	public void createConnection() throws SQLException {
		String urlStr = "jdbc:sqlserver://localhost:1433;databaseName=JDBCDemoDB;TrustServerCertificate=true;"
				+ "user=sa;password=00000000";
		this.conn = DriverManager.getConnection(urlStr);
		boolean status = !conn.isClosed();
		
		if(status) {
			System.out.println("開啟連線");
		}
		
	}
	
	public void closeConn() throws SQLException {
		if(conn!=null) {
			conn.close();
			System.out.println("連線關閉");
		}
	}
	
}
