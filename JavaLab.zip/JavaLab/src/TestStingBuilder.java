
public class TestStingBuilder {

	public static void main(String[] args) {

		//用加號 會產生新的物件
		//新物件不受pool管理， 會在heap區， 可能浪費記憶體
		
		StringBuilder builder = new StringBuilder();
		for(int i =0; i<10; i++) {
			builder.append(i);
		}
		System.out.println(builder);
		
		
		
	}

}
