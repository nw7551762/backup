
public class TestFor {

	public static void main(String[] args) {
		int sum=2;
		for( int i=1; i<=100; i=i+2 ) {
			sum =sum+i;
		}
		

		
		System.out.println(sum);
	}

}
