package expection;

import java.io.File;
import java.io.FileNotFoundException;

public class TestCheckedExpection2 {

	public static void main(String[] args) {
		
		try {
			checkFile("C:\\java\\HelloWorlda.java");
		}catch (FileNotFoundException e) {
			e.printStackTrace();	
		}
	}
	
	public static void checkFile( String filePath) throws FileNotFoundException {
		  File file = new File(filePath);
		  if( !file.exists() ) {
		  		//FileNotFoundException fn = new FileNotFoundException();
		  		throw new FileNotFoundException( " 找不到 " +filePath );
		  }
	}
	
}
