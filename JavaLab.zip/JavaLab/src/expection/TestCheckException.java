package expection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.zip.ZipException;

public class TestCheckException {

	public static void main(String[] args) throws IOException {
				FileReader fr = new FileReader("C:\\java\\Helloorld.java");
		
		
		
	}

}
