package expection;

public class TestExpection {

	public static void main(String[] args) {
		try {	
			int a =1;
			int c=1;
			int[] arr= {};
			
			System.out.println("c=" + c--);
			int b = a/c;
			System.out.println("b=" + b);
			System.out.println(arr[0]);
			
//		}catch (ArithmeticException | ArrayIndexOutOfBoundsException ex) {
//			ex.printStackTrace();
//		}catch (Exception  ex) {
//			ex.printStackTrace();
		}finally {
			System.out.println("一定會執行的區域");
		}
		System.out.println("Done");
		
		
		
	}

}
