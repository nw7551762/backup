
public class TestStirng {

	public static void main(String[] args) {
		
		//存在string pool，相同字串 相同位址
		String name = "Jason";
		String name1 = "Jason";
		System.out.println(name==name1);
		
		name1 = "Vincent";
		
		//存在heap
		String name2 = new String();
		
		System.out.println(name.equals(name2));
		System.out.println( "aabdd".indexOf("aab") );
		System.out.println( "aabdd".contains("aab") );
		
		
		System.out.println( "aabdd".substring(1,3) );
		
		System.out.println( String.format("%.2f", 123.4156));
		
		System.out.printf("ok\n");
		
		
	}

}
