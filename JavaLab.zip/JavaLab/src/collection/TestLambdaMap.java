package collection;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public class TestLambdaMap {
	
	public static Map<String, Integer> result = new HashMap<>();
	
	public static void main(String[] args) {

		vote( "小英", 1 );
		vote( "小名", 1 );
		vote( "小黃", 1 );
		vote( "小黃", 1 );
		vote( "小英", 2 );
		System.out.println(result);
	}
	
	public static Integer setVoteToZero(String name) {
		return 0;
	}
	
	public static void vote( String name, int tickets ) {
		
		result.computeIfAbsent(name, ( key) -> 0);
		result.computeIfAbsent(name, TestLambdaMap::setVoteToZero);
		result.computeIfPresent(name, (key,value)->value+tickets );
//		result.computeIfPresent(name, new BiFunction<String, Integer, Integer>() {
//			@Override
//			public Integer apply(String key, Integer value) {
//				return value+tickets;
//			}
//			
//		});
		
//		if( result.containsKey(name) ) {
//			int newTickets = result.get(name)+tickets;
//			result.put( name,newTickets );
//		}else {
//			result.put(name, tickets);
//		}
	}
		
}
