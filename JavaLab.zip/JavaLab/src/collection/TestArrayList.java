package collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.function.Consumer;

public class TestArrayList {

	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList();
		list.add("Hello");
		list.add("World");
		
		System.out.printf("大小: %d\n", list.size());
		System.out.printf("indexof0: %s\n", list.get(0));
		
		for( int i=0; i<list.size(); i++ ) {
			String item = list.get(i);
			System.out.println(item);
		}
		
//		for( Object item : list ) {
//			System.out.println(item);
//		}
		
		Iterator it = list.iterator();
		while( it.hasNext() ) {
			Object item = it.next();
			System.out.println(item);
			
		}
		
		
		System.out.println("------------------foreach");
		list.forEach( t -> System.out.println(t) );
		
	}

}
