package collection;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class TestTreeSet {

	public static void main(String[] args) {
		
//		Comparator com = new Comparator() {
//
//			@Override
//			public int compare(Object o1, Object o2) {
//				
//				return (Integer)o1 > (Integer)o2  ? -1 : (Integer)o1 == (Integer)o2 ? 0 : 1;
//			}
//		};
		
		DescOrderComparator comparator = new DescOrderComparator();
		Set set =  new TreeSet((Object o1, Object o2) -> {
				
				return (Integer)o1 > (Integer)o2  ? -1 : (Integer)o1 == (Integer)o2 ? 0 : 1;
			}
		);
		set.add(4);
		set.add(3);
		set.add(2);
		set.add(1);
		
		for( Object item: set ) {
			System.out.println(item);
			
		}
		
		
	}

}
