package collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class TestHashMap {
	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>() ;
		
		
		map.put("John", 2000);
		map.put("David", 1000);
		map.put("Tom", 5000);
		
		System.out.printf("Tom's salary = %d \n", map.get("Tom"));		
		map.put("Tom", 3000);
		System.out.printf("Tom's salary = %d \n", map.get("Tom"));	
		
		
//		for( Object item : map.keySet()  ) {
//			System.out.println( item );
//		}
		
//		Set keys = map.keySet();
//		Iterator it = keys.iterator();
//		while( !it.hasNext() ) {
//			Object key = it.next();
//			System.out.println( map.get(key) );
//		}
		
		
		Set< Entry<String, Integer> > entrySet = map.entrySet();
		int sum =0;
		for(  Entry<String, Integer> entry: entrySet  ) {
			
			//Map.Entry entry = ( Map.Entry ) item;
			Integer salary = (Integer) entry.getValue();
			
			sum += salary.intValue();
			
			System.out.printf("%s 's salary = %d\n", 
					entry.getKey(),entry.getValue() );
			
		}
		
		
		
		
		
	}
}
