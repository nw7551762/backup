package collection;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.print.attribute.HashAttributeSet;

public class TestHashSet {

	public static void main(String[] args) {
		Set set = new LinkedHashSet();
		set.add("Hello");
		set.add("World");
		
		for( Object item : set  ) {
			System.out.println(item);
		}
		
		
	}

}
