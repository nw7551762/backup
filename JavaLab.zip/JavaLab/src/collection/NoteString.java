package collection;

public class NoteString {
    private String content;

    public NoteString(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
