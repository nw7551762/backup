package collection;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

public class TestLambdaInSet {
	public static void main(String[] args) {
		
		Set<String> word = new HashSet<>();
		word.add("Hello");
		word.add("World");
		word.add("a");
		word.add("ab");
		word.add("abc");
		word.add("abcasd");
		
		word.removeIf(  (w)-> w.length()<5  );
		
		System.out.println(word);
		
//		word.removeIf(new Predicate<String>() {
//			@Override
//			public boolean test(String t) {
//				return t.length() <5; 
//			}
//		});
	}
	
	
}
