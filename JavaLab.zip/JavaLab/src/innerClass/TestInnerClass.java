package innerClass;

import interFace.Accountant;

public class TestInnerClass {

	public static void main(String[] args) {
			People p =new People(1.7, 60);
			p.printBMI();
			
			Accountant acc = new Accountant() {
				@Override
				public void 報稅() {
					System.out.println("報稅");
				}
			};
			
			acc.報稅();
		
		
	}

}
