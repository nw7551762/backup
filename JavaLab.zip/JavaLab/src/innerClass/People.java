package innerClass;

public class People {
	private double height;
	private double weight;
	
	
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}

	public People(double height, double weight) {
		this.height = height;
		this.weight = weight;
	}
	
	
	public void printBMI() {
		InnerClass inner = new InnerClass();
		System.out.println("BMI: "+ inner.BMI());
	}
	
	
	private class InnerClass{
		public double BMI() {
			return weight / (height*height);
		}
		
		
	}
	
	
}
