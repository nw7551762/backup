package io;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import org.omg.CORBA.SetOverrideType;

public class TestFile {

	public static void main(String[] args) {

		File dir = new File("C:\\eclipse");
		System.out.println(dir.getName());
		
		File[] files = dir.listFiles();
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy/M/d a hh:mm");
		
		int counter = 0;
		long totalSize = 0;
		Set set = new TreeSet();
		Set<File> sortedSet = new TreeSet<>( ( f1,  f2) -> {
//				File f1 = (File) o1;
//				File f2 = (File) o2;
				return f1.length()>f2.length() ? -1: ( f1.length()<f2.length() ? 1:0 ) ;
			
		} );
		
		for( File f : files ) {
			System.out.println(f.getName() + (f.isDirectory() ? "目錄" : "") );
			long lastModifed = f.lastModified();
			Date date = new Date(lastModifed);
			System.out.println(format.format(date));
			if( !f.isDirectory() ) {
//				counter++;
//				totalSize += f.length();
				set.add( f );
			}
		}
//		for (File f : sortedSet) {
//			System.out.println( f.getName() );
//		}
		
//		for( Object  i : set ) {
//			for(File f : files) {
//				long lastModifed = f.lastModified();
//				Date date = new Date(lastModifed);
//				if( !f.isDirectory() && ( f.length()== (long)i ) ) {
//					System.out.println( f.getName() );
//				}
//			}
//				
//			}
		
		}
//		System.out.println(counter);
//		System.out.println(totalSize);
		
		

}
