package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import pack1.Item;

public class StartReader {

	public static void main(String[] args) throws MalformedURLException {

		//URL url = new URL("https://www.twse.com.tw/exchangeReport/MI_INDEX?response=csv&date=20210507&type=ALL");
		
		try(	//InputStream is = url.openStream();
				FileInputStream is = new FileInputStream("C:\\java\\MI_INDEX_ALL_20210507.csv");
				InputStreamReader isr = new InputStreamReader(is, "MS950");
				BufferedReader br = new BufferedReader(isr);
				){
			
				Map<String, Stock> data = new HashMap();
			
				String line;
				Map<String, Stock> itme = data;
				while( (line = br.readLine()) !=null ) {
					//System.out.println(  line  );
					String[] fields = line.split("\",\"");
					String firstColumn = fields[0];
					firstColumn = firstColumn.replace("=","");
					firstColumn = firstColumn.replace("\"", "");
					if( isStockNumber(firstColumn) ) {
						//System.out.println(firstColumn);
						Stock stock = new Stock(firstColumn);
						stock.setName(fields[1]);
						stock.setOpen(  getPrice(fields[5])	);
						stock.setHigh(  getPrice(fields[6])	);
						stock.setLow(  getPrice(fields[7])	);
						stock.setClose(  getPrice(fields[8])	);
						itme.put(firstColumn, stock);
					}
				}
				//System.out.println( data.get("2330") );		
				String stockNumber;
				Scanner scanner = new Scanner(System.in);
				System.out.println("請輸入股票代號或名稱");
				
				while(   (stockNumber = scanner.nextLine()).length()>0  ) {
					Stock stock = data.get(stockNumber);
					if( stock==null ) {
						Set<String> keys = data.keySet();
						for( String id : keys ) {
							Stock item = data.get(id);
							if( item.getName().contains(stockNumber) ) {
								
								System.out.println(item);
							}
							
						}
						
					}else {
						System.out.println(itme.get(stockNumber));
						
					}
					System.out.println("請輸入股票代號或名稱");
				}
				
				
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}

	public static boolean isStockNumber( String str ) {
		if( str.length() <4 ) {
			return false;
		}
		for(int i =0; i<4; i++) {
			if( !Character.isDigit(str.charAt(i))  ) {
				return false;
			}
		}
		return true;
	}
	
	public static double getPrice(	String field) {
		if( field.equals("--") ) {
			return 0.0;
		}
		field = field.replace(",", "");
		return Double.parseDouble(field);
		
		
	}
}

	
