package io;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadFIle {

	public static void main(String[] args) {

		try (   FileInputStream fis = new FileInputStream("C:\\java\\io_1.txt") ;   
				BufferedInputStream bis = new BufferedInputStream(fis);
			)
			{
			
			System.out.printf("一開始 %d byte\n",bis.available());
			int byteValue = bis.read();
			System.out.printf("讀一個byte，剩下 %d byte\n",bis.available());
			
			System.out.println( "byte值 " + byteValue );
			System.out.println( "acii對應 " + (char)byteValue );
			
			while( ( byteValue = bis.read() ) != -1) {
				
				System.out.println( (char)byteValue );
			}
//			fis.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
