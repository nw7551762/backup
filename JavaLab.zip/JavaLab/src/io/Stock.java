package io;

import java.util.Objects;

public class Stock {

	private final String stockID;
	private String name;
	private double open;
	private double high;
	private double low;
	private double close;
	
	public Stock(String stockID) {
		this.stockID = stockID;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getOpen() {
		return open;
	}
	public void setOpen(double open) {
		this.open = open;
	}
	public double getHigh() {
		return high;
	}
	public void setHigh(double high) {
		this.high = high;
	}
	public double getLow() {
		return low;
	}
	public void setLow(double low) {
		this.low = low;
	}
	public double getClose() {
		return close;
	}
	public void setClose(double close) {
		this.close = close;
	}
	public String getStockID() {
		return stockID;
	}
	
	
	
	
	@Override
	public int hashCode() {
		return Objects.hash(stockID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stock other = (Stock) obj;
		return Objects.equals(stockID, other.stockID);
	}

	@Override
	public String toString() {
		
		return String.format("證券代號:%s, 名稱:%s, 開:%.2f, 高:%.2f, 低:%.2f, 收:%.2f", stockID, name, open,high,low,close);
	}
	
	
	
}
