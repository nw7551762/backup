package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RemovingStars {

	public static void main(String[] args) {
		String s ="leet**cod*e";
		String a =	removeStars(s);
		
	}
	
	public static String removeStars(String s) {
        
        List list = new ArrayList();
        list =  Arrays.asList(  s.split("")  )  ;
        List ans = new ArrayList();
        
        for( Object a : list ) {
        	if( a.toString().equals("*")  ) {
        		ans.remove( ans.size()-1 );
        	}else {
        		ans.add(a.toString());
        		
        	}
        }
        String str = String.join("", ans);
        System.out.println(str);
        return str;




    }

}
