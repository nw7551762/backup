package test;

public class FindN {

	public static void main(String[] args) {
		sumZero(4);
	}
	
	
	public static int[] sumZero(int n) {
        int[] arr = new int[n];
        int index = 0;
        if( n%2 ==1 ){
            arr[0] = 0;
            n--;
            index++;
        }
        int i=1;
        
        while( n!=0  ){
            arr[ index++ ] = i;   
            arr[ index++ ] = 0-i;      
            n-=2;
            i++;                        
        }
        return arr;
    }

}
