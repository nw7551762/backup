package test;

import java.util.ArrayList;
import java.util.List;

public class MinCostClimbingStairs {

	public static void main(String[] args) {
		

	}
	public int minCostClimbingStairs(int[] cost) {
         List<Integer> list = new ArrayList<>();
         List<Integer> listone = new ArrayList<>();
         List<Integer> listtwo = new ArrayList<>();
         
         for   (  int i=0; i<cost.length+1;i++  ){
            if( i==0 || i==1) {
                list.add( 0 );
                continue;
            }
            list.add( Math.min( list.get(i-1) + cost[i-1] ,list.get(i-2) +cost[i-2]  )  );
            if ( list.get(i-1) + cost[i-1] < list.get(i-2) +cost[i-2]  ) {
            	listone.add(i);
            	listtwo = listone;
            }else { 
            	listone = listtwo;
            	listtwo.add(i);
            }
         }
         for( int a: list ) {
        	 System.out.println(a);
         }
         
        return list.get( list.size() -1 );
    }

}
