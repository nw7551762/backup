package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.w3c.dom.ls.LSOutput;

public class Jdbc {

	public static void main(String[] args) {

File file = new File("C:\\java\\joblist.csv");
    	
		try (	FileInputStream fis = new FileInputStream(file);
				InputStreamReader isr = new InputStreamReader(fis,"utf8");
				
				){
				Iterable<CSVRecord> records;
				records = CSVFormat.EXCEL.parse(isr);
				
				System.out.println("input search condition");
//				Scanner scanner = new Scanner(System.in);
//				String searchCondition = scanner.nextLine();
				int counts = 0;
//				
//				searchJob( records ,searchCondition , counts );
				
		    	
		    	
		    	
		    	
		    	
		    	
		    	
		    	
		    	} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
		    	
		    	
		   
		
		
		
	}
	
	public static void searchJob( Iterable<CSVRecord> records, String searchCondition, int counts ) {
		for (CSVRecord record : records) {
    	    String data = record.get(0); //職缺描述
    	    if( data.contains(searchCondition) ) {
    	    	System.out.println(data);
    	    	counts++;
    	    	}
    	  
    		}
    	if( counts !=0 ) {
    	    System.out.println(  counts + " results meets the condition ");
    	}else {
    	    System.out.println("no result meets the condition");	
    	}
	}

}
