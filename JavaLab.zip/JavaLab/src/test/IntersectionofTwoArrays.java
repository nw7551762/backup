package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class IntersectionofTwoArrays {

	public static void main(String[] args) {
		int[] nums1 = {1,2,2,1};
		int[] nums2 = {2,2};
		int[] result = intersection(nums1,nums2 );
		System.out.println(result.length);
		for( int  i : result ) {
			
		}
	}
	
	
	public static int[] intersection(int[] nums1, int[] nums2) {
		Set<Integer> resultlist = new HashSet<>( );
        Set<Integer> set1 = new HashSet<>( );
        for( int i=0; i<nums1.length; i++  ) {
        	set1.add(nums1[i]);
        }
        for( int i=0; i<nums2.length; i++  ) {
        	if(   set1.contains( nums2[i]  ) ) {
        		resultlist.add(nums2[i]);
        	}
        }
		
        int[] result = new int[ resultlist.size() ];
        int r=0;
        for( Integer i : resultlist ) {
        	result[r++] = i;
        }
        
        return result;
    }
}
