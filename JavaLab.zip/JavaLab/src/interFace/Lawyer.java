package interFace;

public interface Lawyer {
	/*public*/ void 訴訟();
	
	
	
}
