package interFace;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SimCard extends Product implements Warrantable, Expirable {
	
	private Date expireDate;
	private int warranty;
	public SimCard(String name, int price, Date expireDate, int warranty) {
		super(name, price);
		this.expireDate = expireDate;
		this.warranty = warranty;
	}
	
	
	@Override
    public String desc() {
        String description = super.desc();
        SimpleDateFormat format = new SimpleDateFormat(
        		"yyyy/MM/dd");
        description = description +",最後開卡日："+format.format(expireDate)
        +",  可用data"+ warranty +"天"  ;
        return description;
    }


	@Override
	public int 保固天數() {
		return this.warranty;
	}

	@Override
	public Date 最後期限() {
		return expireDate;
	}
	
	
	
	
	
}
