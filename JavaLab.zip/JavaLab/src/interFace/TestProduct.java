package interFace;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.jws.soap.SOAPBinding;

public class TestProduct {

	public static void main(String[] args) {
		
		Notebook nb = new Notebook("Asus",30000,30);
		System.out.printf(" NB: %s, price: %d \n",
				nb.getName(),nb.getPrice());
		System.out.println(nb.desc());
		
		Product item = nb;
		System.out.println( item.desc() );
		System.out.println( nb.getWarranty() );
		// item 型別是Product 不能使用Product沒定義的方法
		//System.out.println( item.getWarranty() );
		
		Notebook item2 = (Notebook) item;
		if ( item instanceof Food ) {
			Food item3 = (Food) item;
		}
		
		Date expDate = Util.getDate(2022, 9, 28);
		Food food = new Food("肉鬆", 100, expDate);
		System.out.println(food.desc());
		

		SimCard simCard = new SimCard("日本漫遊", 700,  Util.getDate(2022, 10, 31), 7);
		System.out.println(simCard.desc()  );
		
		
		
		Product[] list = { nb, food, simCard };
		
		buy(list);
		

		
	}
	
	
	public static void buy(Product[] products) {
		int sum=0;
		for( Product item : products ) {
			if ( item instanceof Expirable ) {
				
				Expirable expItem = (Expirable) item;
				Date now = new Date();
				if( expItem.最後期限().before(now) ) {
					System.out.println( item.desc() +", 商品已過期!");
					continue;
					
				}
				
			}
			
			System.out.println("買入"+item.desc());
			sum+= item.getPrice();
		}
		System.out.println("總價:"+sum);
	}
	
	
	

}
