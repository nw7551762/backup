package interFace;

public interface Warrantble {
	public static final int MAX_WARRANTY = 365;
	int 保固天數();
	default int 檢測費用() {
		return 500;
	}
	
	static int 退費手續費() {
		return 100;
	}
	
}
