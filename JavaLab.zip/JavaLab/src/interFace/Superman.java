package interFace;

public class Superman implements Lawyer, Accountant {
	
	public static void main(String[] args) {
		
		Superman s = new Superman();
		s.訴訟();
		s.報稅();
		
		
	}

	@Override
	public void 訴訟() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void 報稅() {
		// TODO Auto-generated method stub
		
	}
	
	
}