package interFace;

public interface Warrantable {
	int 保固天數();
	
}
