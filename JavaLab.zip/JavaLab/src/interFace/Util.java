package interFace;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Util {
	public static Date getDate( int year, int month, int day) {
		
		GregorianCalendar calendar = new GregorianCalendar(year, month-1, day );
		return calendar.getTime();
		 
	}
}
