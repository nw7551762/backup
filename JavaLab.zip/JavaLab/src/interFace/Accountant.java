package interFace;

public interface Accountant {
	void 報稅();
}
