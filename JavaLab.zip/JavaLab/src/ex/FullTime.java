package ex;

public class FullTime extends Teacher{

	public FullTime(String name, int totalHours, int rate) {
		super(name, totalHours, rate);
	}

	@Override
	public double salary() {
		return 9*this.getRate()+((this.getTotalHours()-9)*this.getRate()*0.8);
	}

	
	
	
}
