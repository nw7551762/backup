package ex;

public class PartTime extends Teacher{
	
	public PartTime(String name, int totalHours, int rate) {
		super(name, totalHours, rate);
	}

	@Override
	public double salary() {
		return this.getTotalHours()* this.getRate();
	}
	
	
	
}
