package ex;

public class Manager extends FullTime{

	private int rank;
	
	public Manager(String name, int totalHours, int rate, int rank) {
		super(name, totalHours, rate);
		this.rank = rank;
	}

	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	@Override
	public double salary() {
		return super.salary() + rank*500 ;
	}

}
