package ex;

import java.util.HashMap;

import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;

public class TestTeacher {

	public static void main(String[] args) {
		PartTime John = new PartTime("John", 400, 9);
		PartTime Mary = new PartTime("Mary", 300, 4);
		FullTime Peter = new FullTime("Peter", 400, 9);
		FullTime Paul = new FullTime("Paul", 300, 12);
		
		Manager Fang = new Manager("Fang", 500, 12, 3);
		
		TeacherDB T = new TeacherDB();
		T.store("John", John);
		T.store("Mary", Mary);
		T.store("Peter", Peter);
		T.store("Paul", Paul);
		T.store("Fang", Fang);
		
		
		John.desc();
		Mary.desc();
		Peter.desc();
		Paul.desc();
		
		System.out.println(John.afterTaxlns());
		System.out.println( Fang.salary() );
		Fang.desc();
		
		
		
		T.printAll();
		System.out.println( "總薪資: " + T.totalOfAll());
	}
	

}
