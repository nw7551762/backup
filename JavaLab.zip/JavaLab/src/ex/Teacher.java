package ex;

import java.util.HashMap;

public abstract class Teacher {
	private String name;
	private int totalHours;
	private int rate;
	
	public Teacher(String name, int rate, int totalHours) {
		this.name = name;
		this.totalHours = totalHours;
		this.rate = rate;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public int getTotalHours() {
		return totalHours;
	}
	public void setTotalHours(int totalHours) {
		this.totalHours = totalHours;
	}
	
	

	public abstract double salary();
	public  double afterTaxlns() {
		return salary() *0.9 -100;
	}
	
	public void cmp(Teacher b) {
		if ( this.salary() > b.salary() ) {
			System.out.println( this.name + " salary is higher than " + b.name );
		}
	}
	
	public void desc() {
		System.out.printf("name: %s, rate: %d, totalHours: %d, salary: %f \n", this.name, this.rate, this.totalHours, this.salary());
		
	}
}
