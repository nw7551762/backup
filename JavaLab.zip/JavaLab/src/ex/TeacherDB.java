package ex;

import java.util.HashMap;

public class TeacherDB {
		HashMap<String,Teacher> T =new HashMap<String,Teacher>();

		void store(String name,Teacher t)
		{
			T.put(name,t);
		}

		double totalOfAll()
		{
			double sum=0;
			for(Teacher t : T.values())
			{
				sum+=t.afterTaxlns();
			}
			return sum;
		}
		
		public void printAll() {
			int sum=0;
			for( Teacher teacher : T.values() ) {
				System.out.printf("%s ",teacher.getName());
			}
			System.out.println();
		}
	}
