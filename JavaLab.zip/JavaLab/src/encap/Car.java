package encap;

public class Car {
	private String model;
	private int price;
	private String color;
	
	//constructor
	
	public Car( String model, String color ) {
		this.color = color;
		setModel(model);
	}
	public Car(String color) {
		this("Yaris",color);
	}
	public Car() {
		this("Yaris","red")
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	public String getColor() {
		return color;
	}
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
		if(this.model.equals("Prius")) {
			this.price = 1099000;
		}else if(this.model.equals ("Yaris") ){
			this.price = 575000;
		}else {
			System.out.println("型號錯誤");
		}
	}
	
	public int getPrice() {
		return price;
	}
	
	
}
