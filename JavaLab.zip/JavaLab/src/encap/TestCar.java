package encap;

public class TestCar {

	public static void main(String[] args) {
		Car car = new Car("Prius");
		//car.setModel("Prius");
		System.out.printf("型號:%s，價錢:%d，顏色:%s\n", 
				car.getModel(), car.getPrice(), car.getColor()	);		
		
		
		
		
	}

}
