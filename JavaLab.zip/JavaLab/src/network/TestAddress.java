package network;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class TestAddress {

	public static void main(String[] args) {

		try {
			InetAddress localHost = InetAddress.getLocalHost();
			System.out.println(  localHost.getHostAddress()  );
			
			System.out.println( InetAddress.getByName("www.google.com")   );
			
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		
		
		
	}

}
