package network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) {

		System.out.println("請輸入連線主機ip");
		Scanner scanner = new Scanner(System.in);
		String ip = scanner.nextLine();
		System.out.println("請輸入要連線的port");
		String port = scanner.nextLine();
		
		try (
				Socket socket = new Socket( ip, Integer.parseInt(port) );
				InputStream is = socket.getInputStream();
				InputStreamReader isr = new InputStreamReader(is, "utf8");
				OutputStream os = socket.getOutputStream();
				OutputStreamWriter ows = new OutputStreamWriter(os, "utf8");
				BufferedReader br = new BufferedReader(isr);
				
				) {
			
			Thread receiveMeassgeThread = new Thread(
					new Runnable() {
						
						@Override
						public void run() {
							String messageFromServer;
							try {
								while(  (messageFromServer = br.readLine()) != null  ) {
									System.out.println("接收到server傳送訊息:"+messageFromServer);
									
								}
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
					
			);
					
			receiveMeassgeThread.setName("接收執行緒");
			receiveMeassgeThread.setDaemon(true);
			receiveMeassgeThread.start();
			
			
			
			System.out.println("請輸入要傳送的訊息，或者輸入stop停止連線");
			String line;
			while( (line = scanner.nextLine()) != null && !line.equalsIgnoreCase("stop")   ) {
				ows.write(line+"\r\n");
				ows.flush();
				
				System.out.println("請輸入要傳送的訊息，或者輸入stop停止連線");
				
			}
			
			System.out.println("Client 停止運作");
			
			
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		}
		
		
		
		
	}

}
