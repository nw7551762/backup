package network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {

	public static void main(String[] args) {
		
		System.out.println("server啟動中，請連8080");

		try ( 
				ServerSocket ssc = new ServerSocket(8080);
				Socket socket = ssc.accept();
				InputStream is = socket.getInputStream();
				OutputStream os = socket.getOutputStream();
				InputStreamReader isr = new InputStreamReader(is,"UTF8");
				OutputStreamWriter osw = new OutputStreamWriter(os,"UTF8");
				BufferedReader br = new BufferedReader(isr);
				Scanner scanner = new Scanner(System.in);
			){
			
				InetSocketAddress remote = (InetSocketAddress) socket.getRemoteSocketAddress();
				System.out.printf("收到%s(%s)的連線\n",remote.getHostName() ,remote.getAddress().getHostAddress() );
			
				
				Thread writeMessageThread = new Thread( 
						new Runnable() {
					
							@Override
							public void run() {
								System.out.println("請輸入回應訊息");
								String message;
								try {
									while( ( message= scanner.nextLine()) !=null  ){
											osw.write(message+"\r\n");
											osw.flush();
										
									}} catch (IOException e) {
											e.printStackTrace();
									}
								}
							}
				);
				
				writeMessageThread.setName("回應執行緒");
				writeMessageThread.setDaemon(true);
				writeMessageThread.start();
				
				String line;
				while( (line = br.readLine()) != null ) {
					System.out.println("收到訊息 "+line);
					
				
				}
				System.out.println("server 結束");
				
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
	}

}
