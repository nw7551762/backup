package func;

public class People {
	double weight;
	double height;
	
	// static 屬性/function 不須物件就能呼叫 function不能使用物件一般屬性，需要傳入argument
	static final int OVER_WEIGHT_BMI = 24;
	
	public static double BMI( double h, double w ) {
		return w/(h*h);
	}
	
	
	public double getBMI() {
		double bmi = People.BMI(height,weight);
		return bmi;
	}
	
}
