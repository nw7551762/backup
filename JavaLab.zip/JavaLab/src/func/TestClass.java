package func;

public class TestClass {

	public static void main(String[] args) {
			
		int sum  = add(1, 2);
	}
	
	
	
	public static int add( int a, int b ) {
		int sum = a+b;
		System.out.printf("a+b = %d\n", sum);
		return sum;
	}

}
