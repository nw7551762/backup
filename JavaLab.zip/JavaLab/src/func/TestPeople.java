package func;

public class TestPeople {

	public static void main(String[] args) {
		People p = new People();
		p.weight = 80;
		p.height = 1.8;
		double bmi = p.getBMI();
		System.out.println(bmi);
		System.out.println("overWeightBMI = "+People.OVER_WEIGHT_BMI);
		
		System.out.printf("%.2f\n",People.BMI(1.7,60));
//		recur(1,1,10,0);
	}
//	public static void recur(int i, int j, int n, int count) {
//		if(count==n) {
//			return;
//		}
//		int sum = i+j;
//		System.out.println(sum);
//		count++;
//		recur(j,sum,n,count);
//	}
}
