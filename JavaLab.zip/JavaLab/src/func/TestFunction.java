package func;

public class TestFunction {

	public static void main(String[] args) {
			int add = add(1,2,3,4,5);
			System.out.println(add);
	}
	public static void add(int... a) {
		int sum =0;
		for(int value :a) {
			sum+=value;
		}
		return sum;
	}
}
