package thread;

public class TestThread {

	public static void main(String[] args) {
		
		Runnable r = ( ) -> {
			for( int i = 0; i<5; i++ ) {
				System.out.println("倒數" +(5-i)+"秒");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			System.out.println( Thread.currentThread() +"執行結束" );
		};
		
		
		Thread t1 = new Thread(
			() -> {
					for( int i = 0; i<5; i++ ) {
						System.out.println("倒數" +(5-i)+"秒");
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					
					System.out.println( Thread.currentThread() +"執行結束" );
				
			}
		);
		t1.setName("倒數執行續");
		t1.setDaemon(false);
		t1.start();
		
		try {
			t1.join(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		System.out.println("main執行結束"+Thread.currentThread());
		
	}

}
