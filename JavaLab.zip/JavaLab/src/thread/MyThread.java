package thread;

public class MyThread extends Thread{

	@Override
	public void run() {

		for( int i = 0; i<5; i++ ) {
			System.out.println("倒數" +(5-i)+"秒");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println( Thread.currentThread() +"執行結束" );
	
	
	
	}
	
	
	
}
