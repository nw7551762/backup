package array;

public class TestEmployeeArray {

	public static void main(String[] args) {
		Employee[] emps = new Employee[2];
		
		emps[0] = new Employee();
		emps[1] = new Employee();
		
		emps[0].empno = 1;
		emps[0].name = "a";
		
		emps[1].empno = 2;
		emps[1].name = "b";
		
		for(int i = 0; i<emps.length; i++) {
			System.out.println(emps[i].empno + emps[i].name );
		}
		
		
	}

}
