package array;

public class TestArray {

	public static void main(String[] args) {
		
		int [] ages = new int[10];
		ages[0] = 1;
		ages[1] = 2;
		ages[2] = 3;
		ages[3] = 4;
		ages[4] = 5;
		
		System.out.printf("index %d = %d\n",1 ,ages[1]);
		
		//int [][] x = new int[5][4];
		int [][] x = { {1,2,3} , {4,5,6} , {7,8,9} };
		
		// no. of rows
		System.out.println( x.length );
		// no. of collum
		System.out.println( x[0].length );
		
		for(int i =0 ; i<x.length; i++) {
			for( int j =0; j<x[i].length ; j++) {
				if(x[i][j]!= 0 ) {
					System.out.printf(" [%d][%d] = %d\n", i , j , x[i][j]);
				}
			}
		}
		
		for( int[] row : x) {
			for( int value : row)
				System.out.println(value);
		}
		
	}

}
