package array;

public class Employee {
	int empno;
	String name;
}
