package pack1;

public class Item {
	int a;

}
