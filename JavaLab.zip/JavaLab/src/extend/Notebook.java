package extend;

public class Notebook extends Product {
	
	
	public int warranty;
	public Notebook(String name, int price, int warranty) {
//		setName(name);
//		setPrice(price);
//		this.name = name;
//		this.price = price;
//		name price在父類別已經建構過，用super建構就ok
		super(name, price);	
		this.warranty = warranty;
	}
	
	@Override
	public String desc() {
		String infoFromSuper = super.desc();
		String info = String.format("%s, 保固:%d", 
				infoFromSuper,warranty);
		return info;
	}
	
	public int getWarranty() {
		return warranty;
	}
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	
	
	
	
	
}
