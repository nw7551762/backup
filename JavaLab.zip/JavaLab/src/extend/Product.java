package extend;

public abstract class Product {
	public static final double TAX = 0.05;
	
	static {
		System.out.println("隨著類別只會載入一次");
		
	}
	
	protected String name;
	protected int price;
	
	public Product(String name, int price) {
		this.name = name;
		this.price = price;
	}
	public Product() {
	}
	
	
	//public abstract int calc ( int quantity );
	
		
	
	
	
	
	public String desc() {
		String info = String.format("名稱:%s, 價錢:%d", 
				name, price);
		return info;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
}
