package extend;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TestProduct {

	public static void main(String[] args) {
		
		Notebook nb = new Notebook("Asus",30000,30);
		System.out.printf(" NB: %s, price: %d \n",
				nb.getName(),nb.getPrice());
		System.out.println(nb.desc());
		
		Product item = nb;
		System.out.println( item.desc() );
		System.out.println( nb.getWarranty() );
		// item 型別是Product 不能使用Product沒定義的方法
		//System.out.println( item.getWarranty() );
		
		Notebook item2 = (Notebook) item;
		if ( item instanceof Food ) {
			Food item3 = (Food) item;
		}
		
		GregorianCalendar calendar = new GregorianCalendar(2022, Calendar.SEPTEMBER, 28 );
		Date expDate = calendar.getTime();
		Food food = new Food("肉鬆", 100, expDate);
		System.out.println(food.desc());
		
		Product[] list = { nb, food };
		
		buy(list);
	}
	
	
	public static void buy(Product[] products) {
		int sum=0;
		for( Product item : products ) {
			System.out.println("買入"+item.desc());
			sum+= item.getPrice();
		}
		System.out.println("總價:"+sum);
	}
	
	
	

}
