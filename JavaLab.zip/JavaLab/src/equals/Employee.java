package equals;

import java.util.Objects;

public class Employee {
	private String id;
	
	public Employee(String id) {
		this.id = id;
	}
	
	@Override
	public boolean equals(Object obj) {
		if( obj instanceof Employee ) {
			Employee emp =(Employee) obj;
			return this.id.equals(emp.id);
		}
		
		return false;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println(Employee GC!);	
		super.finalize();
	}
	@Override
	public String toString() {
		return String.format("Employee (%s)", this.id);
	}
}
