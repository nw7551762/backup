package equals;

public class TestEquals {
	public static void main(String[] args) {
		
		Employee e1 = new Employee("001");
		
		Class clazz = e1.getClass();
//		System.out.println("clazz");
//		
//		System.out.println(Employee.class);
//		System.out.println(clazz == Employee.class);
//		System.out.println(int.class);
//		System.out.println(void.class);
		
		Employee e2 = new Employee("001");
		
//		System.out.println(e1.equals(e2));
		
		e2.toString();
		
		System.gc();
	}
}
