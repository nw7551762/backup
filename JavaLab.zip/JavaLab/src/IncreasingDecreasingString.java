
class Solution {
	    public String sortString(String s) {
	    	 char[] sChar = new char [ s.length() ];
	         int[] arr =  new int[25];
	 	        
	 	    sChar = s.toCharArray();

	 	    // System.out.println(sChar);
	 	        
	         // for( int i=0; i<26;i++ ){
	         //     arr[ sChar[i] -'a' ] ++;   
	         // }
	 	    
	 	    sChar.toString();
	 	    
	 	    System.out.println(   );
	 	    
	    }
	}	
	