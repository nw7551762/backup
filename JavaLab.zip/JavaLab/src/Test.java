public class Test {
	private static int i = 1;
	public static void main(String argv[]){
		int i = 2;
		print();
	}
  //DO NOT CHANGE
	public static void print(){
		System.out.println(2%2); 
		
		System.out.println();
	}
}