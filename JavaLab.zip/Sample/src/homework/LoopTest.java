package homework;

public class LoopTest {
    public static void main(String[] args) {
        //請列印出1－100中的所有質數，並加總質數的總和
        //提示：google : java 質數
    }
}
