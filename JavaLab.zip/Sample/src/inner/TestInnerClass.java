package inner;

public class TestInnerClass {
    public static void main(String[] args) {
        OuterClass a = new OuterClass(1.7,60);
        a.printBMI();         
    }
}
