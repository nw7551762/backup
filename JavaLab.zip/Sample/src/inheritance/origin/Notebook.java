package inheritance.origin;

public class Notebook {

    public String name;
    public int price;
    public int warranty;


}
