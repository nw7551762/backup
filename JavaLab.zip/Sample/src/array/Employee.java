package array;

/**
 * Created by vincent on 2017/6/3.
 */
public class Employee {
    int empno;
    String name;
    long age;
}
