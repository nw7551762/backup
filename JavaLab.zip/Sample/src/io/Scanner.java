package io;

public class Scanner {

	public static void main(String[] args) {

		java.util.Scanner s = new java.util.Scanner(System.in);
		System.out.println( " 請輸入選項 " );
		String ans = s.nextLine();
		
		System.out.println("你輸入的選項為: "+ans);
		
		
		
		
	}

}
