package abs;

public abstract class Animal {
    public abstract String sound();
}
