package interFace;

public interface Warrantable {
     int MAX_WARRANTY = 730;
     int 保固天數();
}
