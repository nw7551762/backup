package pack1;

public class Item {

    public String name;

    public static void main(String[] args) {
        System.out.println("Item 在 category 套件中");
    }

}
