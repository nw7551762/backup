package pack1;

import util.CountDown;

public class TestJar {
    public static void main(String[] args) {
        util.CountDown countDown = new CountDown();
        countDown.run();
    }
}
