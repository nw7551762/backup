import pack1.Item;

public class TestPackage {
    
    public static void main(String[] args) {


        Item item = new Item();
        item.name = "Notebook";

        System.out.println("TestPackage , Hello World "+item.name);

        

    }
}
