package exam.e8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

public class ParseCSV {
    public static void main(String[] args) {
        /*
        將exam/e8/Employee.csv Copy至c:\java
        只能利用Commons csv library來處理csv檔案,注意cvs檔案編碼為MS950
        網址如下  https://commons.apache.org/proper/commons-csv/
        1.下載commons-csv-1.9-bin.zip，解壓縮後將jar放至lib目錄
        2.eclipse中設定library
        3.參考官方的User Guide處理此csv
        4.所有有實作AutoCloseable的物件都必須close
        5.不可自行將csv中的千分號移除，不可以改動csv中的內容
        取得薪水的加總
         */
    	
    	
    	File file = new File("C:\\java\\Employees.csv");
    	
		try (	FileInputStream fis = new FileInputStream(file);
				InputStreamReader isr = new InputStreamReader(fis,"MS950");
				
				){
			
				Iterable<CSVRecord> records;
				records = CSVFormat.EXCEL.parse(isr);
				
				List<Integer> listInIntegers = new ArrayList<>();
				int sum=0;
				
		    	for (CSVRecord record : records) {
		    	    String data = record.get(2);
		    	    if( !data.equals("薪水") ) {
		    	    	data = data.replace(",", "");
		    	    	listInIntegers.add( Integer.parseInt(data)  );
		    	    }
		    	}
		    	
		    	for (Integer i : listInIntegers) {
					sum+=i;
				}
		    	
		    	System.out.println(sum);
	    	
			
		}catch( FileNotFoundException e ){
			e.printStackTrace();
		}catch( IOException e ){
			e.printStackTrace();
		}
    	
    		
    	}

    }

