package exam.e6;

import java.util.HashMap;
import java.util.Map;

public class MapTest {
    public static void main(String[] args) {

         People p1 = new People("001",21);
         People p2 = new People("002",33);
         People p3 = new People("003",41);
         //實作1:請實作一個「泛型」的Map中的key值為people的id，value為people物件，將上述三個people放入Map中

         Map<String, People> map = new HashMap<>();
         map.put(p1.getId(), p1);
         map.put(p2.getId(), p2);
         map.put(p3.getId(), p3);
         
         //實作2:請用for迴圈或者iterator，計算Map中三人的平均年齡，列印到小數以下第一位
         int totalAge = 0;
         for( String item : map.keySet() ) {
        	 totalAge += map.get(item).getAge();
         }
         double avg = (double)totalAge/ (double) ((map.keySet().size()+1));
         
         
         System.out.println(avg);
         
    }
}
