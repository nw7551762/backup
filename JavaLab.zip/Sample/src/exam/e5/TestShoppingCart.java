package exam.e5;

public class TestShoppingCart {

	public static void main(String[] args) {

	}

}
