package exam.e5;

public class Notebook extends Product {


    public Notebook(String name, int price) {
        super(name, price);
    }
}
