package exam.e5;

public class Food extends Product {

    public Food(String name, int price) {
        super(name, price);
    }
}
