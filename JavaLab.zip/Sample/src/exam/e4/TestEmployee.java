package exam.e4;

public class TestEmployee {

	public static void main(String[] args) {
		Employee emp = new Employee(1, "emp", 2000);
		Manager mng = new Manager(2, "mng", 3000, 500);
		
		System.out.println(emp.getSalary());
		System.out.println(mng.getSalary());
		
		
		
		
		
	}

}
