package equals;

public class TestToString {
    public static void main(String[] args) {
        Employee employee = new Employee("002");
        System.out.println(employee);
        
    }
}
