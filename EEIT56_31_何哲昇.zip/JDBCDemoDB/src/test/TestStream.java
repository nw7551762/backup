package test;

import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import topic1.Job;

public class TestStream {

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<>();
		Stream<Integer> stream = Stream.of(1,2,3,4,5);
//		stream.distinct().forEach( n -> System.out.println(n) );
		
//		list =  stream.filter( n -> n<3 ).collect(Collectors.toList());
		list.forEach(n ->System.out.println(n));
		
		System.out.println(  list.stream().anyMatch( i -> i ==3 ) );
		
		
		
	}

}
