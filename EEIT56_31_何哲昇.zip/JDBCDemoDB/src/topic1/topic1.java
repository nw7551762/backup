package topic1;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.zip.CheckedOutputStream;

import javax.imageio.stream.FileImageOutputStream;
import javax.swing.text.html.HTMLDocument.Iterator;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.w3c.dom.ls.LSOutput;

import com.ispan.util.ConnectionFactory;

//run in cmd
//java -cp ".;C:\JDBCWorkspace\exejar\sqljdbc_11.2cht\mssql-jdbc-11.2.0.jre8.jar;C:\JDBCWorkspace\exejar\commons-csv-1.9.0\commons-csv-1.9.0.jar" topic1.topic1 
public class topic1 {
	public static void main(String[] args) {

		File joblistfile = new File("C:\\JDBCWorkspace\\joblist.csv");
		File outputfile = new File("C:\\JDBCWorkspace\\joblistSearchData.csv");
		Connection conn = ConnectionFactory.createMSSQLConnection();
		Topic1Dao dao = new Topic1Dao(conn);    	
		
		try (	
				FileOutputStream fos = new FileOutputStream( outputfile);
				BufferedOutputStream bos = new BufferedOutputStream(fos);
				){

				Scanner scanner = new Scanner(System.in);
				String input;
				Job job;
				List<Job> jobs;
				String[] strings;
				
				boolean action = true;
				while( action ) {
					System.out.println("輸入功能選項  1:搜尋 2:增加 3:刪除 4:修改 5:結束 ");
					int i  =  scanner.nextInt();
					if( i==5 ) {
						action = false;
						break;
					}
					switch (i) {
					case 1:
						System.out.println("搜尋條件  1:id 2:collumn index");
						int index = scanner.nextInt();
						if( index==1 ) {
							System.out.println("輸入搜尋id");
							job = dao.search( scanner.nextInt() );
							switch( askIfAction(scanner) ){
							case 1:
								jobOutputCsv(job, bos);
								System.out.println("已存入檔案, 檔案位址: C:\\JDBCWorkspace\\joblistSearchData.csv ");
							break;
							case 2:
								dao.delete(job);
							break;
							default:
								action = false;
							break;
						}
						}else if (index==2) {
							System.out.println("輸入: index,搜索條件 (逗號分隔不須空格)");
							input = scanner.next();
							strings =  input.split(",");
							jobs = dao.search( Integer.parseInt( strings[0] ), strings[1]);
							switch( askIfAction(scanner) ){
								case 1:
									jobOutputCsv(jobs, bos);
									System.out.println("已存入檔案, 檔案位址: C:\\JDBCWorkspace\\joblistSearchData.csv ");
								break;
								case 2:
									dao.delete(jobs);
								break;
								default:
									action = false;
								break;
							}
						}
						break;
					case 2:
						System.out.println("新增方式 1:console輸入 2:CSV輸入");
						index = scanner.nextInt();
						switch (index) {
						case 1:
							input =  scanner.next();
							strings = input.split(",");
							if( strings.length ==20 ) {
								Job j = new Job(Integer.parseInt(strings[0]), strings[1], strings[2], strings[3], strings[4], strings[5], strings[6], strings[7], strings[8], strings[9], strings[10], strings[11], strings[12], strings[12], strings[14], strings[15], strings[16], strings[17], strings[18], strings[19]);
								dao.insertjob(j);
							}else {
								System.out.println("資料與欄位個數不符");
							}
						break;
						case 2:
							System.out.println("輸入CSV檔案位置");
							try (	FileInputStream newfis = new FileInputStream(scanner.next());
									InputStreamReader newisr = new InputStreamReader(newfis,"utf8");
									BufferedReader newbr = new BufferedReader(newisr);
									){
								inputCSVtoDB(newbr, dao);
							}
						break;
						}
						break;
					case 3:
						System.out.println("輸入要刪除欄位的id");
						dao.delete(scanner.nextInt());
						break;
					case 4:
						System.out.println("輸入要修改的id, salary_L, salary_U ");
						strings = scanner.next().split(",");
						dao.updateSalById(Integer.parseInt(strings[0]), strings[1], strings[2]);
					}
				}
						
		} catch (IOException | SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
	}	
	
	//job output成 csv檔
	public static void jobOutputCsv( Job job, BufferedOutputStream bos ) throws IOException {
		bos.write(  job.Col().getBytes()  );
		bos.write(  "\n".getBytes()  );
		bos.write(job.toString().getBytes());
		bos.write(  "\n".getBytes()  );
	}
	public static void jobOutputCsv( List<Job> jobs, BufferedOutputStream bos ) throws IOException {
		bos.write(  jobs.get(0).Col().getBytes()  );
		bos.write(  "\n".getBytes()  );
		for( int i =0; i<jobs.size(); i++ ) {
			bos.write(jobs.get(i).toString().getBytes());
			bos.write(  "\n".getBytes()  );
		}
	}
	
	public static int askIfAction( Scanner scanner ) {
		System.out.println("搜尋結果: 1:output CSV 2:刪除 3:結束");
		int i = scanner.nextInt();
		return i;
	}
	
	public static void inputCSVtoDB(BufferedReader isr, Topic1Dao dao) throws IOException, SQLException {
		Iterable<CSVRecord> records = CSVFormat.EXCEL.parse(isr);
		//寫入資料庫
		
		CSVInsertIntoJoblist(records,dao);
		System.out.println("寫入成功");
	}
	
 	public static void CSVInsertIntoJoblist( Iterable<CSVRecord> records, Topic1Dao dao) throws SQLException {
		//record讀出加到list內
		List<Job> joblist = new LinkedList<>();
		
		for( CSVRecord record : records ) {
			joblist.add( CSVRecordToJob(record) );
		}
		//寫入資料庫
		dao.insertJob(joblist);
		System.out.println("資料庫寫入成功");
	}
	public static Job CSVRecordToJob( CSVRecord row ) {
		Job job = new Job();
		job.setOCCU_DESC( row.get(0) );
		job.setWK_TYPE( row.get(1) );
		job.setCJOB_TYPE( row.get(2) );
		job.setCJOB_NAME1( row.get(3) );
		job.setCJOB_NO( row.get(4) );
		job.setCJOB_NAME2( row.get(5) );
		job.setAVAILREQNUM( row.get(6) );
		job.setSTOP_DATE( row.get(7) );
		job.setJOB_DETAIL( row.get(8) );
		job.setCITYNAME( row.get(9) );
		job.setEXPERIENCE( row.get(10) );
		job.setWKTIME( row.get(11) );
		job.setSALARYCD( row.get(12) );
		job.setSALARY_L( row.get(13) );
		job.setSALARY_U( row.get(14) );
		job.setEDGRDESC( row.get(15) );
		job.setURL_QUERY( row.get(16) );
		job.setCOMPNAME( row.get(17) );
		job.setTRANDATE( row.get(18) );
		
		return job;
	}
}
